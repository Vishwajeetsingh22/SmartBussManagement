package com.buspass.smartbuspass.service;

import com.buspass.smartbuspass.entity.User;
import com.buspass.smartbuspass.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataSeeder implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Override
    public void run(String... args) {
        // Only insert if no users exist
        if (userRepository.count() == 0) {
            userRepository.save(new User(
                    "student",
                    "{noop}student123",
                    "STUDENT",
                    "Default Student",
                    "student@buspass.com"
            ));
            userRepository.save(new User(
                    "conductor",
                    "{noop}conductor123",
                    "CONDUCTOR",
                    "Default Conductor",
                    "conductor@buspass.com"
            ));
            userRepository.save(new User(
                    "admin",
                    "{noop}admin123",
                    "ADMIN",
                    "Default Admin",
                    "admin@buspass.com"
            ));

            System.out.println("✅ Default users seeded into MongoDB!");
        } else {
            System.out.println("✅ Users already exist in MongoDB, skipping seed.");
        }
    }
}