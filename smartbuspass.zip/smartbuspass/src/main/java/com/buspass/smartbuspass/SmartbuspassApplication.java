package com.buspass.smartbuspass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartbuspassApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartbuspassApplication.class, args);
	}

}
