package com.buspass.smartbuspass.service;

import com.buspass.smartbuspass.entity.User;
import com.buspass.smartbuspass.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RegistrationService {

    @Autowired
    private UserRepository userRepository;

    public String register(String fullName, String email, String phone,
                           String username, String password, String route) {

        if (userRepository.existsByUsername(username)) {
            return "USERNAME_TAKEN";
        }
        if (userRepository.existsByEmail(email)) {
            return "EMAIL_TAKEN";
        }

        User user = new User();
        user.setFullName(fullName);
        user.setEmail(email);
        user.setPhone(phone);
        user.setUsername(username);
        user.setPassword("{noop}" + password);
        user.setRoute(route);
        user.setRole("STUDENT");
        user.setActive(true);
        user.setPassStatus("PENDING");

        userRepository.save(user);
        return "SUCCESS";
    }
}