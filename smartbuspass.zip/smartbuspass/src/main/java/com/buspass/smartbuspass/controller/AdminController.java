package com.buspass.smartbuspass.controller;

import com.buspass.smartbuspass.entity.User;
import com.buspass.smartbuspass.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private UserRepository userRepository;

    // ── Dashboard with real users from MongoDB ──
    @GetMapping("/dashboard")
    public String adminDashboard(Model model) {
        List<User> users = userRepository.findAll();
        long totalUsers    = users.size();
        long activePasses  = users.stream().filter(u -> "ACTIVE".equals(u.getPassStatus())).count();
        long pendingPasses = users.stream().filter(u -> "PENDING".equals(u.getPassStatus())).count();

        model.addAttribute("users", users);
        model.addAttribute("totalUsers", totalUsers);
        model.addAttribute("activePasses", activePasses);
        model.addAttribute("pendingPasses", pendingPasses);

        return "admin/dashboard";
    }

    // ── Add User ──
    @PostMapping("/users/add")
    public String addUser(
            @RequestParam String fullName,
            @RequestParam String email,
            @RequestParam String phone,
            @RequestParam String username,
            @RequestParam String password,
            @RequestParam String role,
            @RequestParam(required = false) String route) {

        User user = new User();
        user.setFullName(fullName);
        user.setEmail(email);
        user.setPhone(phone);
        user.setUsername(username);
        user.setPassword("{noop}" + password);
        user.setRole(role.toUpperCase());
        user.setRoute(route);
        user.setActive(true);
        user.setPassStatus("ROLE_STUDENT".equals(role.toUpperCase()) ? "ACTIVE" : "N/A");

        userRepository.save(user);
        return "redirect:/admin/dashboard";
    }

    // ── Delete User ──
    @PostMapping("/users/delete/{id}")
    public String deleteUser(@PathVariable String id) {
        userRepository.deleteById(id);
        return "redirect:/admin/dashboard";
    }

    // ── Approve Pass ──
    @PostMapping("/users/approve/{id}")
    public String approveUser(@PathVariable String id) {
        userRepository.findById(id).ifPresent(user -> {
            user.setPassStatus("ACTIVE");
            userRepository.save(user);
        });
        return "redirect:/admin/dashboard";
    }

    // ── Revoke Pass ──
    @PostMapping("/users/revoke/{id}")
    public String revokeUser(@PathVariable String id) {
        userRepository.findById(id).ifPresent(user -> {
            user.setPassStatus("REVOKED");
            userRepository.save(user);
        });
        return "redirect:/admin/dashboard";
    }
}