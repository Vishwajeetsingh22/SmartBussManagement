package com.buspass.smartbuspass.controller;

import com.buspass.smartbuspass.service.RegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    @Autowired
    private RegistrationService registrationService;

    @GetMapping("/login")
    public String loginPage() { return "login"; }

    @GetMapping("/register")
    public String registerPage() { return "register"; }

    @PostMapping("/register")
    public String registerSubmit(
            @RequestParam String fullName,
            @RequestParam String email,
            @RequestParam String phone,
            @RequestParam String username,
            @RequestParam String password,
            @RequestParam String route,
            Model model) {

        String result = registrationService.register(
                fullName, email, phone, username, password, route);

        switch (result) {
            case "USERNAME_TAKEN" -> model.addAttribute("error", "Username already taken.");
            case "EMAIL_TAKEN"    -> model.addAttribute("error", "Email already registered.");
            case "SUCCESS"        -> model.addAttribute("success",
                    "Registration successful! Your pass is pending approval. Please login.");
        }
        return "register";
    }

    @GetMapping("/student/dashboard")
    public String studentDashboard() { return "student/dashboard"; }

    @GetMapping("/conductor/dashboard")
    public String conductorDashboard() { return "conductor/dashboard"; }
}