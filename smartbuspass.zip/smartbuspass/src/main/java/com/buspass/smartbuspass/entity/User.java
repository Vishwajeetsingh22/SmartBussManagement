package com.buspass.smartbuspass.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.index.Indexed;

@Document(collection = "users")
public class User {

    @Id
    private String id;

    @Indexed(unique = true)
    private String username;

    private String password;
    private String role;
    private String fullName;
    private String email;
    private String phone;
    private String route;
    private boolean active = true;
    private String passStatus = "PENDING"; // PENDING, ACTIVE, EXPIRED

    // ── Constructors ──
    public User() {}

    public User(String username, String password, String role,
                String fullName, String email) {
        this.username = username;
        this.password = password;
        this.role     = role;
        this.fullName = fullName;
        this.email    = email;
        this.active   = true;
    }

    // ── Getters & Setters ──
    public String getId()                   { return id; }
    public void   setId(String id)          { this.id = id; }

    public String getUsername()             { return username; }
    public void   setUsername(String u)     { this.username = u; }

    public String getPassword()             { return password; }
    public void   setPassword(String p)     { this.password = p; }

    public String getRole()                 { return role; }
    public void   setRole(String r)         { this.role = r; }

    public String getFullName()             { return fullName; }
    public void   setFullName(String n)     { this.fullName = n; }

    public String getEmail()                { return email; }
    public void   setEmail(String e)        { this.email = e; }

    public String getPhone()                { return phone; }
    public void   setPhone(String p)        { this.phone = p; }

    public String getRoute()                { return route; }
    public void   setRoute(String r)        { this.route = r; }

    public boolean isActive()               { return active; }
    public void    setActive(boolean a)     { this.active = a; }

    public String getPassStatus()           { return passStatus; }
    public void   setPassStatus(String s)   { this.passStatus = s; }
}