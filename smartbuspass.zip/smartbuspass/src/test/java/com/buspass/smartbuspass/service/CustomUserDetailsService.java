package com.buspass.smartbuspass.service;

import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return switch (username) {
            case "student" -> User.builder()
                    .username("student")
                    .password("{noop}student123")
                    .roles("STUDENT")
                    .build();
            case "conductor" -> User.builder()
                    .username("conductor")
                    .password("{noop}conductor123")
                    .roles("CONDUCTOR")
                    .build();
            case "admin" -> User.builder()
                    .username("admin")
                    .password("{noop}admin123")
                    .roles("ADMIN")
                    .build();
            default -> throw new UsernameNotFoundException("User not found: " + username);
        };
    }
}